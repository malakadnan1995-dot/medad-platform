import test from 'node:test';
import assert from 'node:assert/strict';
import { existsSync, readFileSync, statSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { curriculum, lessons, totalLessons, totalQuestions } from '../src/curriculum.js';

const root = resolve(fileURLToPath(new URL('..', import.meta.url)));

test('المسار منظّم في ثلاث وحدات وستة دروس بمحتوى قابل للقراءة', () => {
  assert.equal(curriculum.modules.length, 3);
  assert.equal(totalLessons, 6);
  const ids = lessons.map((lesson) => lesson.id);
  assert.equal(new Set(ids).size, ids.length, 'معرّفات الدروس فريدة');
  for (const lesson of lessons) {
    assert.ok(lesson.title && lesson.summary && lesson.duration);
    assert.ok(lesson.blocks.length >= 6, `الدرس ${lesson.id} لديه محتوى فعلي`);
    for (const block of lesson.blocks) {
      assert.ok(['lead', 'heading', 'paragraph', 'list', 'steps', 'figure', 'callout'].includes(block.type));
      const copy = [block.text, block.title, block.caption, ...(block.items || [])].filter(Boolean).join(' ');
      assert.ok(copy.length > 0, `الكتلة في ${lesson.id} ليست فارغة`);
      assert.doesNotMatch(copy, /lorem ipsum|placeholder|sample content|TODO/i);
    }
  }
});

test('أسئلة الاختبار متعددة الخيارات ولها مفاتيح إجابة وشروح صالحة', () => {
  assert.equal(totalQuestions, 8);
  for (const [index, question] of curriculum.quiz.entries()) {
    assert.ok(question.question.length > 20, `نص السؤال ${index + 1}`);
    assert.equal(question.options.length, 4);
    assert.ok(Number.isInteger(question.answer) && question.answer >= 0 && question.answer < question.options.length);
    assert.ok(question.explanation.length > 30);
  }
});

test('ملفات القراءة الصوتية العربية موجودة للدروس والاختبار والصفحة الرئيسية', () => {
  const files = [
    'overview.mp3',
    ...lessons.map((lesson) => `${lesson.id}.mp3`),
    ...curriculum.quiz.map((_, index) => `quiz-${index}.mp3`)
  ];
  assert.equal(files.length, 15);
  for (const file of files) {
    const path = resolve(root, 'public/audio', file);
    assert.ok(existsSync(path), `ملف الصوت مفقود: ${file}`);
    assert.ok(statSync(path).size > 20_000, `ملف الصوت فارغ أو غير مكتمل: ${file}`);
  }
});

test('رسم الدرس والصفحات المعلنة موجودان', () => {
  assert.ok(existsSync(resolve(root, 'assets/learning-cycle.svg')));
  const manifest = JSON.parse(readFileSync(resolve(root, 'manus-routes.json'), 'utf8'));
  assert.equal(manifest.routes.length, 4);
  assert.ok(manifest.routes.some((entry) => entry.path === '/'));
  assert.ok(manifest.routes.some((entry) => entry.path === '/#/lesson/:slug'));
});

test('المشروع قابل للتشغيل دون مكتبات إضافية', () => {
  const pkg = JSON.parse(readFileSync(resolve(root, 'package.json'), 'utf8'));
  assert.ok(pkg.scripts.start);
  assert.ok(pkg.scripts.test);
  assert.equal(pkg.type, 'module');
  assert.deepEqual(pkg.dependencies || {}, {});
});
